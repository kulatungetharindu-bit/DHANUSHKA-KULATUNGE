package make_my_trip;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Main {

	public static void main(String[] args) throws InterruptedException  {
		// TODO Auto-generated method stub
		

		/*
		 * ChromeOptions options = new ChromeOptions();
		 * options.addArguments("--remote-allow-origins=*");
		 * options.addArguments("--start-maximized");
		 */

 
		  // ✅ Create ChromeOptions FIRST
        ChromeOptions options = new ChromeOptions();

        options.addArguments("--start-maximized");
        options.addArguments("--disable-blink-features=AutomationControlled");
        options.addArguments("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");

        options.setExperimentalOption("excludeSwitches",
                new String[]{"enable-automation"});
        options.setExperimentalOption("useAutomationExtension", false);

        // ✅ Pass options into ChromeDriver
        WebDriver driver = new ChromeDriver(options);





       try {
           Thread.sleep(3000);  
       } catch (InterruptedException e) {
           e.printStackTrace();
       }

       driver.get("https://www.makemytrip.global/");
       System.out.println("The site was loaded");
       Thread.sleep(3000);
       
       WebElement firstPopUpCloseButton = driver.findElement(By.xpath("//span[@class='commonModal__close']"));
	   firstPopUpCloseButton.click();
	   WebElement fromTile = driver.findElement(By.xpath("//span[normalize-space()='From']"));
	   fromTile.click();
	   Thread.sleep(3000);
	   WebElement fromTilePickList = driver.findElement(By.xpath("//input[@placeholder='From']"));
	   fromTilePickList.sendKeys("HYD");
	   Thread.sleep(4000);
	   WebElement fromTilePickListTopMostSearchResult = driver.findElement(By.xpath("//p[normalize-space()='Rajiv Gandhi International Airport']"));
	   fromTilePickListTopMostSearchResult.click();
       Thread.sleep(3000);
	   
	   
	   WebElement toTile = driver.findElement(By.xpath("//span[normalize-space()='To']"));
	   toTile.click();
	   WebElement toTilePickList = driver.findElement(By.xpath("//input[@placeholder='To']"));
	   toTilePickList.click();
	   toTilePickList.clear();
	   toTilePickList.sendKeys("MAA");

	  WebElement toTilePickListTopMostSearchResult = driver.findElement(By.xpath("//li[@id='react-autowhatever-1-section-0-item-0']//span[contains(@class,'makeFlex flexOne spaceBetween appendRight10')]"));
	   toTilePickListTopMostSearchResult.click();
       Thread.sleep(3000);
       
       
       WebElement departureCalenderCell = driver.findElement(By.xpath("//div[contains(@aria-label,'Sat Nov 29 2025')]//div[contains(@class,'dateInnerCell')]"));
      departureCalenderCell.click();
       
      
      WebElement returnTile = driver.findElement(By.xpath("//p[@class='latoBlack font12 greyText lineHeight16']"));
      returnTile.click();
      Thread.sleep(4000);
      WebElement returnCalenderCell = driver.findElement(By.xpath("//div[contains(@aria-label,'Wed Dec 24 2025')]//div[contains(@class,'dateInnerCell')]"));
      returnCalenderCell.click();
     
       WebElement searchButton = driver.findElement(By.xpath("//a[@class='primaryBtn font24 latoBold widgetSearchBtn ']"));
       searchButton.click();
	  Thread.sleep(8000);
	  
       
	  String expectedSearchResultsPageTitle="MakeMyTrip";
	   String searchResultsPageTitle = driver.getTitle();
	   System.out.println("The page title = " + searchResultsPageTitle);
	   
	   if (expectedSearchResultsPageTitle.equals(searchResultsPageTitle)) {
		System.out.println("The search results page was loaded properly");
	} else {
		System.out.println("ERROR: The search results page was not loaded properly");
	}
	   
}
	




}