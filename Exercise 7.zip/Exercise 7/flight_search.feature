Feature: Flight Search on MakeMyTrip

  Scenario: Search for a round-trip flight from HYD to MAA
    Given I launch Chrome browser and open "https://www.makemytrip.com/"
    When I click on Flights tab
    And I select "Round Trip" option
    And I enter From location as "HYD" and To location as "MAA"
    And I select Departure date and Return date
    And I click on Search button
    Then I should see the flight search results page