package stepDefinitions;

import io.cucumber.java.en.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import java.time.Duration;

public class FlightSearchSteps {

    WebDriver driver;

    @Given("I launch Chrome browser and open {string}")
    public void launchBrowser(String url) {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\LENOVO\\Desktop\\Chrome Driver\\DHANUSHKA\\chromedriver-win64\\chromedriver.exe"); // Update path
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        driver = new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get(url);
    }

    @When("I click on Flights tab")
    public void clickFlightsTab() {
        driver.findElement(By.id("tab-flight-tab")).click(); // Use actual Flights tab locator
    }

    @When("I select {string} option")
    public void selectRoundTrip(String option) {
        WebElement roundTrip = driver.findElement(By.xpath("//li[contains(@data-cy,'roundTrip')]"));
        if(!roundTrip.isSelected()) {
            roundTrip.click();
        }
    }

    @When("I enter From location as {string} and To location as {string}")
    public void enterLocations(String from, String to) throws InterruptedException {
        WebElement fromInput = driver.findElement(By.id("fromCity"));
        fromInput.click();
        fromInput.sendKeys(from);
        Thread.sleep(1000);
        driver.findElement(By.xpath("//p[contains(text(),'"+from+"')]")).click();

        WebElement toInput = driver.findElement(By.id("toCity"));
        toInput.click();
        toInput.sendKeys(to);
        Thread.sleep(1000);
        driver.findElement(By.xpath("//p[contains(text(),'"+to+"')]")).click();
    }

    @When("I select Departure date and Return date")
    public void selectDates() {
        // Example: Selecting today's date for simplicity
        driver.findElement(By.cssSelector("div[data-cy='departureDate']")).click();
        driver.findElement(By.cssSelector(".DayPicker-Day--today")).click();

        driver.findElement(By.cssSelector("div[data-cy='returnDate']")).click();
        driver.findElement(By.cssSelector(".DayPicker-Day--today + .DayPicker-Day")).click();
    }

    @When("I click on Search button")
    public void clickSearch() {
        driver.findElement(By.cssSelector("a[data-cy='search']")).click();
    }

    @Then("I should see the flight search results page")
    public void verifySearchResults() {
        boolean resultsDisplayed = driver.findElement(By.id("flightSearchResults")).isDisplayed(); // Update locator
        if(resultsDisplayed) {
            System.out.println("Flight search results are displayed successfully!");
        } else {
            System.out.println("Flight search results not displayed!");
        }
        driver.quit();
    }
}