// home_page_spec.cy.js

// Using Mocha syntax (describe/it) and Cypress assertions
describe('Automation Panda Demo Site Test', () => {

  // Hook: runs before each test
  beforeEach(() => {
    cy.visit('https://automationpanda.com/2021/12/29/want-to-practice-test-automation-try-these-demo-sites/')
  })

  it('Verify homepage title', () => {
    cy.title().should('include', 'Want to Practice Test Automation? Try These Demo Sites')
  })

  it('Click on Speaking link and verify page title', () => {
    cy.contains('Speaking').click()
    cy.title().should('include', 'Speaking')  // Adjust if the page title is different
  })

  it('Verify Keynote Addresses text is present', () => {
    // Check if the element exists and contains expected text
    cy.contains('Keynote Addresses').should('exist').and('have.text', 'Keynote Addresses')
  })
})