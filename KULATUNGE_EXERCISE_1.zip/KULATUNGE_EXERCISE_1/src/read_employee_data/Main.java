package read_employee_data;

import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;
import java.util.Scanner;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		File file = new File("C:\\Users\\LENOVO\\Desktop\\Test Data\\Exercise_1_Employee_Info.xlsx");
		FileInputStream fis = new FileInputStream(file);
		XSSFWorkbook xssf= new XSSFWorkbook(fis);
		XSSFSheet sheet = xssf.getSheetAt(0);		

		int rowCountInt=sheet.getLastRowNum();
		
		
	    for (int i = 0; i <= rowCountInt; i++) {
			

				
              System.out.print(sheet.getRow(i).getCell(0).getStringCellValue());
              System.out.print(" | ");
              System.out.print(sheet.getRow(i).getCell(1).getStringCellValue());
              System.out.print(" | ");
              System.out.print(sheet.getRow(i).getCell(2).getStringCellValue());
              System.out.print(" | ");
              System.out.print(sheet.getRow(i).getCell(3).getStringCellValue());
              System.out.print(" | ");
              System.out.print(sheet.getRow(i).getCell(4).getStringCellValue());
              System.out.println(" | ");
              
    
			
		}
		
	}

}
